package com.durgesh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningManagemmentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.durgesh.service;

import com.durgesh.model.User;

public interface IUserService {
	
	User saveUser(User user);

}

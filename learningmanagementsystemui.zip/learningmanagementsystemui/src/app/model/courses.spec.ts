import { Courses } from './courses';

describe('Courses', () => {
  it('should create an instance', () => {
    expect(new Courses()).toBeTruthy();
  });
});

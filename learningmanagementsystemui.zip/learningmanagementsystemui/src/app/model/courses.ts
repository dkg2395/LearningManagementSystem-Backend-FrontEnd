export class Courses {

    courseId:number=0;

    courseName:string='';
    courseDuration:number=0;
    courseDescription:string='';
    technology:string='';
    launchUrl:string='';

}
